#include<stdio.h>
struct stu{
	int x;
	double y;
	char c;
};

main()
{
	struct stu temp;
	printf("size=%d\r\n", sizeof(temp));
}
